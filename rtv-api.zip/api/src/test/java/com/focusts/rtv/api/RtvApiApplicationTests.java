package com.focusts.rtv.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RtvApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
